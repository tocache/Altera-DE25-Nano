/* Quartus Prime Version 26.1.0 Build 110 03/26/2026 SC Pro Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(A5EB013BB23BR1) Path("C:/Quartus_projects/Agilex5_test02/output_files/") File("counter_bcd.sof") MfrSpec(OpMask(1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
