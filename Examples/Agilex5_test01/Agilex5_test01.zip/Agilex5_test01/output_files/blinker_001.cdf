/* Quartus Prime Version 26.1.0 Build 110 03/26/2026 SC Pro Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(A5EB013BB23BCS) Path("C:/Quartus_projects/Agilex5_test01/output_files/") File("blinker_001.sof") MfrSpec(OpMask(1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
